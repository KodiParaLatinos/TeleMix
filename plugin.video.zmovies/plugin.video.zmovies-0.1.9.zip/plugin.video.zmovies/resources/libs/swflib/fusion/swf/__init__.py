"""
SWF creation/parsing support.
"""
